# Coba's Creations — Front-End Site (Cloudflare Pages Ready)

## What this is
A complete, deployable static front-end for the public website and customer
booking flow described in the platform spec — sections 46–51 (site map),
59–65 (design system), and 3 (booking flow). Deploy `/dist` to Cloudflare
Pages and it works today, no build step required on Cloudflare's end.

## What is REAL in this build (not just mockup)
- **Delivery window calculation** (spec §20) — actual logic in `js/booking.js`,
  verified against the spec's own worked example (11 AM–5 PM event →
  8:00–10:30 AM delivery window).
- **Pickup window calculation** (spec §21) — event end through +3 hours.
- **Damage/Cleaning Authorization Hold math** (spec §29) — 35% of eligible
  inflatable rental value only, correctly excluding live performers and
  delivery fees, matching the spec's own worked example.
- **Full design token system** (spec §59–61) — exact brand hex values from
  the spec, centrally defined in `css/tokens.css`. Change a value once,
  it updates everywhere.
- **One true global header/footer** — both live in `/partials` and are
  assembled into every page by `build.py`. Edit the partial, re-run the
  build, every page updates. Never hand-edit the generated files in `/dist`
  directly — that recreates the exact "independently-built copies" problem
  a global element is supposed to prevent.
- **Semantic H1–H5 structure**, one H1 per page, throughout.
- **Policy content correctly marked TEMPLATE** per spec §33 — nothing on
  the Policies or FAQ page is presented as approved/final legal language.

## What is SIMULATED (front-end only, clearly marked in-page)
- **Product catalog & availability** — mock data in `js/booking.js`
  (`CATALOG` array). No real inventory database is connected.
- **Order submission** — the booking flow's "Submit Order" button shows a
  confirmation screen but does not create a real order or send a real
  payment email.
- **Contact form** — `js/contact.js` shows a status message but does not
  send anything anywhere.
- **Testimonials** — explicitly does not display invented reviews; shows
  a placeholder noting the Google Business integration is pending.

## What this does NOT include, and why
The full spec describes an operational platform: real payment processing
(Stripe or similar, with live keys and webhooks), a real product/inventory
database, an admin application with authentication and role-based
permissions, SMS notifications, a delivery-routing engine, and reporting.
None of that can exist in a static file bundle — it requires a live backend
(a real database, a payment processor account, an SMS provider, hosting
with server-side compute such as Cloudflare Workers + D1/KV or an external
service) and credentials that only the business owner can provide. Building
that is the next phase, not something a static zip can fake convincingly
without either lying about what works or leaving broken-looking stubs.

## How to make a change
1. Edit the relevant file in `/partials`, `/css`, or `/js` — never the
   generated files directly inside `/dist`.
2. Run `python3 build.py` from the project root.
3. Re-deploy the refreshed `/dist` folder to Cloudflare Pages.

## Deploying to Cloudflare Pages
- Cloudflare Pages → Create a project → Direct Upload → upload the
  contents of `/dist` (or connect a repo and set the build output
  directory to `dist`, build command `python3 build.py`).
- No environment variables or secrets are required for this front-end-only
  build.

## Suggested next steps, in order
1. Get the licensed brand display font file from the owner and swap it in
   for the temporary Baloo 2 fallback in `css/tokens.css`
   (`--font-family-brand-display`).
2. Get the actual circular CC balloon logo file and replace the CSS-drawn
   placeholder mark in `partials/header.html`.
3. Decide on a backend platform (Cloudflare Workers + D1 is a natural fit
   given the Cloudflare deployment target) to implement real product data,
   orders, and payments per spec sections 11–19, 70.
4. Connect a real payment processor for the deposit/balance flow (spec
   §15–19) — this requires the owner's own merchant account.
5. Connect the Google Business API for real testimonials (spec §68).
