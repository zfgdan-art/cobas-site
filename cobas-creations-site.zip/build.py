#!/usr/bin/env python3
"""
Assembles final static HTML pages from shared partials.
Run this after editing header.html, footer.html, or any page-*.html
partial — never hand-edit the generated files in /dist directly,
or your changes will be overwritten and drift from the source partial.
"""
import os

ROOT = os.path.dirname(os.path.abspath(__file__))
PARTIALS = os.path.join(ROOT, 'partials')
DIST = os.path.join(ROOT, 'dist')

PAGES = {
    'index.html': ('Coba\'s Creations | Bounce House & Party Rentals in Kansas City', 'page-home.html'),
    'rentals.html': ('Rentals | Coba\'s Creations', 'page-rentals.html'),
    'live-services.html': ('Live Services | Coba\'s Creations', 'page-live-services.html'),
    'how-it-works.html': ('How It Works | Coba\'s Creations', 'page-how-it-works.html'),
    'about.html': ('About Us | Coba\'s Creations', 'page-about.html'),
    'faq.html': ('FAQ | Coba\'s Creations', 'page-faq.html'),
    'testimonials.html': ('Testimonials | Coba\'s Creations', 'page-testimonials.html'),
    'contact.html': ('Contact Us | Coba\'s Creations', 'page-contact.html'),
    'booking.html': ('Select Your Party Date & Time | Coba\'s Creations', 'page-booking.html'),
    'policies.html': ('Policies & Terms | Coba\'s Creations', 'page-policies.html'),
}

def read(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def main():
    os.makedirs(DIST, exist_ok=True)
    header = read(os.path.join(PARTIALS, 'header.html'))
    footer = read(os.path.join(PARTIALS, 'footer.html'))

    shell = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="Coba's Creations — party rentals and live entertainment serving the Kansas City metro area.">
<link rel="stylesheet" href="css/tokens.css">
<link rel="stylesheet" href="css/main.css">
</head>
<body>
{header}
<main>
{content}
</main>
{footer}
</body>
</html>
"""

    for out_name, (title, partial_name) in PAGES.items():
        content = read(os.path.join(PARTIALS, partial_name))
        html = shell.format(title=title, header=header, content=content, footer=footer)
        with open(os.path.join(DIST, out_name), 'w', encoding='utf-8') as f:
            f.write(html)
        print('Built', out_name)

    # copy static assets
    import shutil
    for sub in ['css', 'js', 'assets']:
        src = os.path.join(ROOT, sub)
        dst = os.path.join(DIST, sub)
        if os.path.exists(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
    print('Done. Static site is in /dist — that folder is what gets deployed to Cloudflare Pages.')

if __name__ == '__main__':
    main()
