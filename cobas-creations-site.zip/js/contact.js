// Front-end only. Wire this to a real endpoint (Cloudflare Worker,
// or a form-handling service) to actually create an Enquiry record
// (spec section 44) and notify staff.
document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('contactForm');
  if (!form) return;
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    document.getElementById('contactStatus').textContent =
      'This is a front-end simulation — no message was actually sent. Connect this form to a backend endpoint to make it real.';
  });
});
