/* =========================================================
   Coba's Creations — booking flow (front-end simulation)
   Real logic: delivery-window calc (spec §20), damage/cleaning
   hold calc (spec §29). Everything else (real availability,
   real order creation, real payment) needs the backend system.
   ========================================================= */

// ---- Mock catalog (replace with real product API) ----
var CATALOG = [
  { id: 'combo-castle', name: 'Castle Bounce Combo', type: 'physical', price: 185, dims: "15' × 15', 13' tall", eligibleForHold: true },
  { id: 'wet-tropical', name: 'Tropical Water Slide', type: 'physical', price: 265, dims: "32' × 12', 16' tall", eligibleForHold: true },
  { id: 'tables-round', name: 'Round Tables (set of 4)', type: 'physical', price: 40, dims: "60\" diameter", eligibleForHold: false },
  { id: 'face-painter', name: 'Face Painter (2 hrs)', type: 'live', price: 300, dims: null, eligibleForHold: false },
  { id: 'dj', name: 'DJ & Music (4 hrs)', type: 'live', price: 400, dims: null, eligibleForHold: false }
];

var DELIVERY_FEE = 45;
var HOLD_RATE = 0.35; // spec §29
var state = { date: null, start: null, end: null, cart: {} };

// ---- Delivery window logic, spec §20 ----
function toMinutes(hhmm) {
  var parts = hhmm.split(':');
  return parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
}
function fromMinutes(mins) {
  var h = Math.floor(mins / 60) % 24;
  var m = mins % 60;
  var ampm = h >= 12 ? 'PM' : 'AM';
  var h12 = h % 12 === 0 ? 12 : h % 12;
  return h12 + ':' + (m < 10 ? '0' + m : m) + ' ' + ampm;
}
function deliveryWindow(startHHMM) {
  var start = toMinutes(startHHMM);
  if (start <= toMinutes('08:00')) {
    // 8:00 event -> 7:00-7:30
    if (start === toMinutes('08:00')) return [toMinutes('07:00'), toMinutes('07:30')];
  }
  if (start === toMinutes('08:30')) return [toMinutes('07:30'), toMinutes('08:00')];
  if (start === toMinutes('09:00')) return [toMinutes('07:30'), toMinutes('08:30')];
  if (start >= toMinutes('09:30')) return [toMinutes('08:00'), start - 30];
  // fallback for times earlier than 8:00 not explicitly specified: use earliest normal window
  return [toMinutes('07:00'), Math.max(toMinutes('07:00'), start - 30)];
}
function pickupWindow(endHHMM) {
  var end = toMinutes(endHHMM);
  return [end, end + 180];
}

// ---- Cart / hold math, spec §29 ----
function cartTotals() {
  var items = Object.keys(state.cart).map(function (id) {
    var p = CATALOG.find(function (c) { return c.id === id; });
    return { product: p, qty: state.cart[id] };
  });
  var subtotal = items.reduce(function (sum, i) { return sum + i.product.price * i.qty; }, 0);
  var holdBasis = items.reduce(function (sum, i) {
    return i.product.eligibleForHold ? sum + i.product.price * i.qty : sum;
  }, 0);
  var hold = Math.round(holdBasis * HOLD_RATE * 100) / 100;
  var total = subtotal + DELIVERY_FEE;
  return { items: items, subtotal: subtotal, delivery: DELIVERY_FEE, holdBasis: holdBasis, hold: hold, total: total };
}

// ---- UI wiring ----
document.addEventListener('DOMContentLoaded', function () {
  var panels = document.querySelectorAll('.booking-panel');
  var pills = document.querySelectorAll('.step-pill');

  function showPanel(n) {
    panels.forEach(function (p) { p.classList.toggle('active', p.dataset.panel === String(n)); });
    pills.forEach(function (p) { p.classList.toggle('active', p.dataset.step === String(n)); });
  }

  var eventDate = document.getElementById('eventDate');
  var startTime = document.getElementById('startTime');
  var endTime = document.getElementById('endTime');
  var windowPreview = document.getElementById('windowPreview');
  var deliveryOut = document.getElementById('deliveryWindowOut');
  var pickupOut = document.getElementById('pickupWindowOut');

  function updateWindowPreview() {
    if (!startTime.value || !endTime.value) return;
    var dw = deliveryWindow(startTime.value);
    var pw = pickupWindow(endTime.value);
    deliveryOut.textContent = fromMinutes(dw[0]) + ' – ' + fromMinutes(dw[1]);
    pickupOut.textContent = fromMinutes(pw[0]) + ' – ' + fromMinutes(pw[1]);
    windowPreview.style.display = 'block';
  }
  startTime.addEventListener('input', updateWindowPreview);
  endTime.addEventListener('input', updateWindowPreview);
  updateWindowPreview();

  document.getElementById('toStep2').addEventListener('click', function () {
    if (!eventDate.value || !startTime.value || !endTime.value) {
      alert('Please select an event date, start time, and end time.');
      return;
    }
    state.date = eventDate.value;
    state.start = startTime.value;
    state.end = endTime.value;
    document.getElementById('selectedDateLabel').textContent =
      'For ' + state.date + ', ' + fromMinutes(toMinutes(state.start)) + ' – ' + fromMinutes(toMinutes(state.end));
    renderCatalog();
    showPanel(2);
  });

  function renderCatalog() {
    var grid = document.getElementById('productGrid');
    grid.innerHTML = '';
    CATALOG.forEach(function (p) {
      var card = document.createElement('label');
      card.className = 'card selectable-card';
      card.innerHTML =
        '<input type="checkbox" data-id="' + p.id + '">' +
        '<div class="card-media">' + (p.type === 'live' ? 'Live' : 'Rental') + '</div>' +
        '<div class="card-body">' +
        '<span class="badge badge-available">Available</span>' +
        '<h3>' + p.name + '</h3>' +
        (p.dims ? '<p class="card-dims">' + p.dims + '</p>' : '') +
        '<p class="card-price">$' + p.price + (p.type === 'live' ? '' : ' / event') + '</p>' +
        '</div>';
      grid.appendChild(card);
    });
    grid.querySelectorAll('input[type=checkbox]').forEach(function (cb) {
      cb.addEventListener('change', function () {
        if (cb.checked) { state.cart[cb.dataset.id] = 1; }
        else { delete state.cart[cb.dataset.id]; }
      });
    });
  }

  document.getElementById('backTo1').addEventListener('click', function () { showPanel(1); });
  document.getElementById('toStep3').addEventListener('click', function () {
    if (Object.keys(state.cart).length === 0) { alert('Select at least one item.'); return; }
    showPanel(3);
  });
  document.getElementById('backTo2').addEventListener('click', function () { showPanel(2); });

  document.getElementById('toStep4').addEventListener('click', function () {
    var name = document.getElementById('custName').value;
    var addr = document.getElementById('custAddress').value;
    var phone = document.getElementById('custPhone').value;
    var email = document.getElementById('custEmail').value;
    if (!name || !addr || !phone || !email) { alert('Please fill in all fields.'); return; }
    renderReview();
    showPanel(4);
  });
  document.getElementById('backTo3').addEventListener('click', function () { showPanel(3); });

  function renderReview() {
    var t = cartTotals();
    var dw = deliveryWindow(state.start);
    var pw = pickupWindow(state.end);
    var html = '';
    t.items.forEach(function (i) {
      html += '<div class="order-line"><span>' + i.product.name + '</span><span>$' + i.product.price + '</span></div>';
    });
    html += '<div class="order-line"><span>Delivery</span><span>$' + t.delivery + '</span></div>';
    if (t.hold > 0) {
      html += '<div class="order-line"><span>Damage/Cleaning Authorization Hold (35% of eligible rentals, released after inspection)</span><span>$' + t.hold.toFixed(2) + '</span></div>';
    }
    html += '<div class="order-line"><span>Delivery window</span><span>' + fromMinutes(dw[0]) + '–' + fromMinutes(dw[1]) + '</span></div>';
    html += '<div class="order-line"><span>Pickup window</span><span>' + fromMinutes(pw[0]) + '–' + fromMinutes(pw[1]) + '</span></div>';
    html += '<div class="order-total"><span>Order Total</span><span>$' + t.total.toFixed(2) + '</span></div>';
    document.getElementById('orderSummary').innerHTML = html;
  }

  document.getElementById('submitOrder').addEventListener('click', function () {
    showPanel('done');
  });
});
